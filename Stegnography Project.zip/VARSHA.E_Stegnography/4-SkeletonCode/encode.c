#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
OperationType check_operation_type(char *argv[])
{
    //Compare the two strings
    //if "-e" --> return e_encode
    if(strcmp(argv[1] ,"-e") == 0)
    {
        return e_encode;
    }
    //if  it is"-d" - return e_decode
    else if(strcmp(argv[1],"-d") == 0)
    {
        return e_decode;
    }
    //if it is " " - return e_unsupported
    else
    {
        return e_unsupported;
    }
}
Status read_and_validate_encode_args(char *argv[],EncodeInfo *encInfo)
{
    //Check the src file is .bmp or not
    if(argv[2] == NULL)
    {      
       //when it is error then print 
                printf("Error : Unable To Perform Operation.Arguments should be > 3.\n");
                printf("For Encoding Arguments Should be :\na.out -e <sourcefile.bmp> <secretfile.txt> <outputfile.bmp> (outputfile is optional)\nFor decoding Arguments should be:\na.out -d <sourcefile.bmp> <outputfile.bmp>\n");
            
        return e_failure;
    }
    else if (strstr(argv[2], ".bmp") != NULL)
    {
        encInfo->src_image_fname = argv[2];
    }
    else
    {
        printf("Encoding Started.\n");
        printf("Checking Argument is Started.\n");
        printf("Error :: Difficulty in checking source file extension .bmp\nDificulty in checking file extensions\n\n");
        return e_failure;
    }
    // Check if the secret file has a valid extension (.txt, .sh, .c)
    if(argv[3] == NULL)
    {
                printf("Error : Unable To Perform Operation.Arguments should be > 3.\n");
                printf("For Encoding Arguments Should be :\na.out -e <sourcefile.bmp> <secretfile.txt> <outputfile.bmp> (outputfile is optional)\nFor decoding Arguments should be:\na.out -d <sourcefile.bmp> <outputfile.bmp>\n");

        return e_failure;
    }
    else if (strstr(argv[3],".txt") != NULL)
    {
        encInfo -> secret_fname = argv[3];
        strcpy(encInfo->extn_secret_file, ".txt");

        printf("Encoding Started.\n");
        printf("Checking Argument is Started.\n");
    }
    else if (strstr(argv[3], ".sh") != NULL)
    {
        encInfo -> secret_fname = argv[3];
        strcpy(encInfo->extn_secret_file, ".sh");
        
        printf("Encoding Started.\n");
        printf("Checking Argument is Started.\n");
    }
    else if (strstr(argv[3], ".c") != NULL)
    {
        encInfo -> secret_fname = argv[3];
        strcpy(encInfo->extn_secret_file, ".c");

        printf("Encoding Started.\n");
        printf("Checking Argument is Started.\n");
    }
    else
    {

        printf("Encoding Started.\n");
        printf("Checking Argument is Started.\n");
        printf("Error :: Difficulty in checking source file extension .txt, .sh, .c\nDificulty in checking file extensions\n");
        return e_failure;  // Invalid secret file extension
    }

    // Store the secret file name
    //encInfo->secret_fname = argv[3];

    // Check if the stego image file argument is provided, else set default name
    if (argv[4] == NULL)
    {
        encInfo->stego_image_fname = "stego.bmp";
        printf("Argument Verified Successfully.\n");
        return e_success;  // Default stego image name
    }
    else if (strstr(argv[4], ".bmp") != NULL)
    {
        encInfo->stego_image_fname = argv[4];  // Use the provided stego image file name
        printf("Argument Verified Successfully.\n");
        return e_success ;
    }
    else
    {
        printf("Error :: Provide output file with .bmp extension.\n");

        return e_failure;  // Invalid stego image file extension
    }

    //return e_success;  // All checks passed successfully
}

uint get_file_size(FILE *fptr_image)
{
    fseek(fptr_image, 0, SEEK_END);
    return ftell(fptr_image);
}
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    //printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    //printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

        return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

        return e_failure;
    }
    printf("Encoding File ::%s\n",encInfo->stego_image_fname);
    // No failure return e_success
    return e_success;
}
Status check_capacity(EncodeInfo *encInfo)
{
    encInfo -> image_capacity = get_image_size_for_bmp(encInfo -> fptr_src_image);
    encInfo -> size_secret_file = get_file_size(encInfo -> fptr_secret);
    if(encInfo -> image_capacity > (strlen(MAGIC_STRING) + sizeof(int) + strlen(encInfo->extn_secret_file) + sizeof(int) + encInfo -> size_secret_file * 8 ) + 54)
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }

}
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    /*Make filepointer into 0th position(rewind(src filepointer))
      from 0 to 54 copy from src to dest
      fread(&buffer (dest),54,1,src filepointer(src))
      fwrite(buffer(src),54,1,dest filepointer(dest))*/

    char buffer[54];
    rewind(fptr_src_image);
    fread(buffer , 54 , 1 ,fptr_src_image);
    fwrite(buffer, 54 , 1 ,fptr_dest_image);
    return e_success;

}
Status encode_byte_to_lsb(char data,char *image_buffer)
{
    int i , get;
    for (i = 7;i >= 0;i--)
    {
        get = (data & (1 << i)) >> i;
        image_buffer[7-i]=image_buffer[7-i] & (~1);
        image_buffer[7-i]=image_buffer[7-i] | get;
    }
    return e_success;
}
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    //Read 8 bytes from the src image
    //call encode_byte_to_lsb
    //Write 8 bytes to output image
    char buffer[8];
    for(int i = 0;i < size;i++)
    {
        fread(&buffer, 8, 1,fptr_src_image);
        encode_byte_to_lsb(data[i],buffer);
        fwrite(buffer, 8, 1,fptr_stego_image);
    }
    return e_success;
}
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    //Encoding the magic string
    if(encode_data_to_image(MAGIC_STRING, strlen(MAGIC_STRING), encInfo->fptr_src_image, encInfo->fptr_stego_image)==e_success)
    {
        return e_success;
    }
    else
    {
        //When the magic string not encoded
        return e_failure;
    }
}

Status encode_int_to_lsb(long data, char *buffer)
{
    int i,get;
    for(i = 31;i >= 0;i--)
    {
        get = (data & (1 << i)) >> i;
        buffer[31-i]=buffer[31-i] & (~1);
        buffer[31-i]=buffer[31-i] | get;
    }
    return e_success;
}
Status encode_secret_file_extn_size(long extn_size,EncodeInfo *encInfo)
{
    //Read 32 byte data
    char buffer[32];

    fread(&buffer, 32, 1,encInfo -> fptr_src_image);
    if(encode_int_to_lsb(extn_size,buffer) == e_failure)
    {
        return e_failure;
    }
    //Write 32 byte data
    fwrite(buffer, 32, 1,encInfo -> fptr_stego_image);

    return e_success;
}
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    //Encoding the file extension

    if(encode_data_to_image(encInfo->extn_secret_file,strlen(encInfo->extn_secret_file),encInfo->fptr_src_image,encInfo ->fptr_stego_image) == e_success)
    {
        return e_success;
    }
}
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    //Read 32 byte data
    char buffer[32];
    fread(&buffer,32,1, encInfo->fptr_src_image);
    //Function call of int to lsb
    encode_int_to_lsb(file_size, buffer);
    //Write 32 byte
    fwrite(buffer,32,1, encInfo->fptr_stego_image);
    return e_success;
}
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    char secret_data [encInfo -> size_secret_file];
    rewind(encInfo -> fptr_secret);
    fread(secret_data, encInfo->size_secret_file,1,encInfo->fptr_secret);
    if(encode_data_to_image(secret_data,encInfo->size_secret_file, encInfo ->fptr_src_image,encInfo ->fptr_stego_image)==e_success)
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    //Read 1 byte from the src image
    //Write 1 byte into the output image
    char buffer;
    while(fread(&buffer,1,1,fptr_src))
    {
        fwrite(&buffer,1,1,fptr_dest);
    }
    return e_success;
}
//Print all the  decoding part (function declaration)
Status do_encoding(EncodeInfo *encInfo)
{

    printf("Open files process started.\n");
    if(open_files(encInfo) == e_success)
    {
        printf("File Opened Successfully.\n");
        printf("Checking capacity to encode message.\n");
        if(check_capacity(encInfo) == e_success)
        {
            printf("Capacity of source file is more than the secret file.\n");
            printf("Header is copying.\n");
            if (copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
            {
                printf("Successfully header is copied.\n");
                printf("Encoding the magic string.\n");
                if(encode_magic_string(MAGIC_STRING, encInfo) == e_success)
                {
                    printf("Magic string Encoded successfully.\n");
                    printf("Encoding the file extension size.\n");
                    if (encode_secret_file_extn_size(strlen(encInfo -> extn_secret_file), encInfo) == e_success)
                    {
                        printf("File extension size Encoded successfully.\n");
                        printf("Encoding the file extension.\n");
                        if(encode_secret_file_extn(encInfo -> extn_secret_file , encInfo) == e_success)
                        {
                            printf("File extension Encoded Successfully(EX: .txt).\n");
                            printf("Encoding secret file size(data size).\n");
                            if(encode_secret_file_size(encInfo -> size_secret_file, encInfo) == e_success)
                            {
                                printf("File size Encoded Successfully.\n");
                                printf("Encoding the Secret Data.\n");
                                if(encode_secret_file_data(encInfo) == e_success)
                                {
                                    printf("Secret Data Encoded Successfully.\n");
                                    printf("Encoding the Remaining Data.\n");
                                    if (copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
                                    {
                                        printf("Remaining Data Encoded Successfully.\n");
                                 
                                        return e_success;                                    
                                    }
                                }
                            }			
                        }
                    }
                }
            }
        }
    }
}
