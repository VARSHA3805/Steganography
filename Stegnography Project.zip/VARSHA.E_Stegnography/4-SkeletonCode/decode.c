#include <stdio.h>
#include <string.h>
#include "decode.h"
#include "types.h"
#include "common.h"
#include <stdlib.h>

/* Read and validate decode arguments */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    // Validate the stego image file is .bmp
    if(argv[2] == NULL)
    {
        //When the argument is null
                printf("Error : Unable To Perform Operation.Arguments should be > 3.\n");
                printf("For Encoding Arguments Should be :\na.out -e <sourcefile.bmp> <secretfile.txt> <outputfile.bmp> (outputfile is optional)\nFor decoding Arguments should be:\na.out -d <sourcefile.bmp> <outputfile.bmp>\n");
        return e_failure;
    }
    else if (strstr(argv[2], ".bmp") != NULL) 
    {
        strcpy(decInfo->encoded_image_fname,argv[2]);
    }
    else
    {

        printf("Decoding Started.\n");
        printf("Checking Argument is Started.\n");
        printf("Error :: Difficulty in checking source file extension .bmp\nDificulty in checking file extensions\n\n");
        return e_failure;
    }

    // Default output file name for decoded secret file
    if (argv[3] == NULL) 
    {
        strcpy(decInfo->output_secret_fname ,"decoded_secret");
        //printf("%s\n",decInfo -> output_secret_fname);
        printf("Decoding Started.\n");
        printf("Checking Argument is Started.\n");
        printf("Arguments Verified Successfully\n");
        return e_success ;
    }
    else if (argv[3] != NULL)
    {
        //Call string token
        strtok(argv[3], ".");
        strcpy(decInfo-> output_secret_fname ,argv[3]);
        printf("Decoding Started.\n");
        printf("Checking Argument is Started.\n");
        return e_success;
    }
    else
    {
        printf("Decoding Started.\n");
        printf("Checking Argument is Started.\n");
        printf("Error :: Difficulty in checking source file extension .bmp\nDificulty in checking file extensions\n\n");
        return e_failure;
    }

}

Status open_image_files(DecodeInfo *decInfo)
{
    // Src Image file
    decInfo ->encoded_image_fptr = fopen(decInfo->encoded_image_fname, "r");
    // Do Error handling
    if (decInfo->encoded_image_fptr == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->encoded_image_fname);

        return e_failure;
    }
    printf("Secret message File :: %s\n",decInfo->encoded_image_fname);
    return e_success;


}
//Skip the 54 byte data
Status skip_bmp_header(DecodeInfo *decInfo)
{
    fseek(decInfo->encoded_image_fptr, 54, SEEK_SET); 
    return e_success;
}

char decode_int_from_lsb(char *buffer)
{
    int i, get;
    char ch = 0;
    for(i = 0; i < 32; i++)
    {
        get = (buffer[i] & 1) << (31 - i);
        ch = ch | get;
    }
    return ch;

}
char decode_byte_from_lsb(char *buffer)
{
    int i, get;
    char ch = 0;
    for(i = 0; i < 8; i++)
    {
        get = (buffer[i] & 1) << (7 - i);
        ch = ch | get;
    }
    return ch;

}
Status decode_magic_string(DecodeInfo *decInfo)
{
    //Read 8 bytes from encoding image
    char buffer[8];
    char magic_str[strlen(MAGIC_STRING) + 1];

    // Decode the magic string
    for (int i = 0; i < strlen(MAGIC_STRING); i++)
    {
        fread(buffer, 8, 1, decInfo->encoded_image_fptr);
        //Call decode byte from lsb
        magic_str[i] = decode_byte_from_lsb(buffer);
    }
    magic_str[strlen(MAGIC_STRING)] = '\0';  

    // Validate the decoded magic string
    if (strcmp(magic_str, MAGIC_STRING) != 0)
    {
        printf("ERROR :: Magic String cannot be decoded.\n");
        return e_failure;
    }

    return e_success;
}
Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
    //Read 32 byte from encoding
    char buffer[32];
    fread(buffer, 32, 1, decInfo->encoded_image_fptr);
    //call decode int from lsb
    decInfo -> extn_size = decode_int_from_lsb(buffer);
    return e_success;
}
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    int i;
    char buffer[8];
    // Array to store the decoded extension, size based on 'extn_size
    char extn[decInfo->extn_size + 1];
    for (i = 0; i < decInfo->extn_size; i++) 
    {
        //Read 8 byte data from encoded image
        fread(buffer, 8, 1, decInfo->encoded_image_fptr);
        extn[i] = decode_byte_from_lsb(buffer);
    }
    extn[i] = '\0'; 
    //Append the decoded extension to the output secret filename
    strcat(decInfo->output_secret_fname, extn);
    return e_success;
}
Status open_output_file(DecodeInfo *decInfo)
{
    decInfo -> output_secret_fptr = fopen(decInfo -> output_secret_fname, "w");
    if(decInfo ->output_secret_fptr == NULL)
    {
        // Check if file opening failed
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->output_secret_fname);

        return e_failure;
    }
    printf("Decode data will store into :: %s\n",decInfo -> output_secret_fname);
    return e_success;

} 
Status decode_secret_file_size(DecodeInfo *decInfo)
{
    char buffer[32];
    //Read 32 byte data
    fread(buffer, 32, 1, decInfo->encoded_image_fptr);
    // Decode the secret file size from the LSB of the buffer
    decInfo->secret_file_size = decode_int_from_lsb(buffer);
    return e_success;
}
Status decode_data_to_image(DecodeInfo *decInfo)
{
    int i ;
    char buffer[8];
    // Array to store decoded secret data, size based on secret file size
    char secret_data[(decInfo-> secret_file_size) + 1];

    for ( i = 0; i < decInfo-> secret_file_size; i++) 
    {
        //Read 8 byte data
        fread(buffer, 8, 1, decInfo->encoded_image_fptr);
        secret_data[i] = decode_byte_from_lsb(buffer);
    }
    secret_data[i] = '\0' ;
    // Write the decoded secret data to the output file
    fwrite(secret_data, decInfo-> secret_file_size, 1, decInfo->output_secret_fptr);
    return e_success;
}
//Function declaration and print
Status do_decoding(DecodeInfo *decInfo)
{   
    printf("Open files process Started.\n");
    if(open_image_files(decInfo) == e_success)
    {
        printf("Files Opened Successfully.\n");
        {
            skip_bmp_header(decInfo);
            printf("Decoding Magic String.\n");
            printf("Skipped Header file.\n");

            if (decode_magic_string(decInfo) == e_success)
            {
                printf("Magic String Decoded Successfully.\n");
                printf("Decoding Secret file Extension size.\n");

                if (decode_secret_file_extn_size(decInfo) == e_success)
                {
                    printf("Secret file extension size decoded Successfully.\n");
                    printf("Decoding secret file extension.\n");
                    if(decode_secret_file_extn(decInfo) == e_success)
                    {
                        printf("Secret file extension Decoded Succeffully.\n");
                        printf("Opening file to store the secret data (Output File).\n");
                        if(open_output_file(decInfo) == e_success)
                        {
                            printf("Output file opened Successfully.\n");
                            printf("Decoding Secret file size.\n");
                            if (decode_secret_file_size(decInfo) == e_success)
                            {
                                printf("Secret file size decoded Successfully.\n");
                                printf("Decoding secret Data.\n");
                                if (decode_data_to_image(decInfo) == e_success)
                                {
                                    printf("Secret Data decoded Successfully.\n");
                                    printf("Storing Data into output file.\n");
                                    printf("Data Stored Successfully.\n");
                                    return e_success;
                            
                                }
                            
                       
                            }
                        }


                    }

                }

            }
        }

    }
    return e_failure;

}

