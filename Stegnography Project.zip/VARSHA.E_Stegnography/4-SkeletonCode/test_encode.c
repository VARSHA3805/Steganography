/* Documentation 
Name : VARSHA.E
Date : 21/11/2024
DES  : Stegnography
*/
#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "decode.h"


int main(int argc,char *argv[])
{
    // Checking the condition if argument greater then 1
    if(argc > 1)
    {
        //Encoding file
        if(check_operation_type(argv) == e_encode)
        {
            //Structure name
            EncodeInfo encInfo;
            if(read_and_validate_encode_args(argv, &encInfo) == e_success)
            {
                //If the condition success print
               if( do_encoding(&encInfo) == e_success)
               {
                   printf("\n..........ENCODING COMPLETED..........\n\n");
               }
            }
        }
        //Decoding file
        else if(check_operation_type(argv) == e_decode)
        {
            DecodeInfo decInfo;
            
            if(read_and_validate_decode_args(argv, &decInfo) == e_success)
            {
                //when decoding success then print
                if(do_decoding(&decInfo) == e_success)
                {
                    printf("\n..........DECODING COMPLETED..........\n\n");
                }
            }

        }
        //when if we use other than -e & -d then it is error
        else
        {
            printf("Error : Unable to proceed operation provide valid type (-e or -d).\n");
        }
        
    }
    else
       {
            printf("Please pass the proper arguments.\n");
       }
    return 0;
}
