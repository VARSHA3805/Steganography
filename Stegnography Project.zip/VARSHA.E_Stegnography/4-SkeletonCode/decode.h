#ifndef DECODE_H
#define DECODE_H

#include "types.h" // Contains user defined types

/* 
 * Structure to store information required for
 * encoding secret file to source Image
 * Info about output and intermediate data is
 * also stored
 */

#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4

typedef struct _DecodeInfo
{
    /*Encoded Source Image info */
    char encoded_image_fname[30]; //To store the file name
    FILE *encoded_image_fptr;

    /* Secret File Info */
    char output_secret_fname[30];
    FILE *output_secret_fptr;
    int extn_size; 
    int  secret_file_size;
} DecodeInfo;


/* Encoding function prototype */

/* Read and validate Decode args from argv */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/* Perform the decoding */
Status do_decoding(DecodeInfo *decInfo);

/* Get File pointers for i/p and o/p files */
Status open_image_files(DecodeInfo *decInfo);

/* Copy bmp image header */
Status skip_bmp_header(DecodeInfo *decInfo);

/* Store Magic String */
Status decode_magic_string(DecodeInfo *decInfo);

/* Decode the extn size */
Status decode_secret_file_extn_size(DecodeInfo *decInfo);

/* Decode secret file extenstion */
Status decode_secret_file_extn(DecodeInfo *decInfo);

Status open_text_file(DecodeInfo *decInfo);
/* Decode secret file size */
Status decode_secret_file_size(DecodeInfo *decInfo);

/* Decode function, which does the real decoding */
Status decode_data_to_image(DecodeInfo *decInfo);

/* Decode a byte into LSB of image data array */
char decode_byte_to_lsb(char *buffer);

/* Decode int from lsb */
char decode_int_from_lsb(char *buffer);

#endif  
